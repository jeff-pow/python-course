# Lab 4 Table Header File

def lab4_table_header():
    print("\n\nStudent Grade Data\n")
    print(f"{'Name':<20}{'ID':>7}{'Grade':>8}")
    print("-----------------------------------")
    
