#Project 1 dictionary with mortgage rates
#Class: CSC295
#Date: 09/15/2023

rates = {"10-Year Fixed, 80% or less LTV":6.050,
    "10-Year Fixed, 80.1-90% LTV":6.250,
    "10-Year Fixed, 90.1-100% LTV": 6.550,
    "15-Year Fixed, 90% or less LTV":6.550,
    "15-Year Fixed, 90.1-100% LTV":6.775,
    "20-Year Fixed, 90% or less LTV":6.825,
    "20-Year Fixed, 90.1-100% LTV":7.125,
    "30-Year Fixed, 90% or less LTV":7.000,
    "30-Year Fixed, 90.1-100% LTV":7.250}
